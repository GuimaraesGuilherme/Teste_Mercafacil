const faker = require("faker-br"); 

it('Ir para o site de cadastro de clientes Mercafacil', () => {
    cy.viewport(1920, 1080)
    cy.visit('https://cadastramento-demo.mercafacil.com/#/home')
    cy.get('.button-height').click()
})

//inserindo o CPF
it('Inserir CPF', () => {
    const meuCpf = faker.br.cpf();
    
    cy.get('.v-input__slot').type(meuCpf)
    cy.get('.v-input__append-outer > .v-btn').click()
})

it('Finalizar cadastro PF', () => {
    //preenchendo o nome 
    cy.get(':nth-child(1) > :nth-child(2) > .v-input > .v-input__control > .v-input__slot').type('Guilherme Guimaraes')

    //Selecionando genero
    cy.get('.v-input--radio-group__input > :nth-child(1) > .v-input--selection-controls__input > .v-input--selection-controls__ripple').click()
    
    //preenchendo o celular
    cy.get(':nth-child(1) > :nth-child(4) > .v-input > .v-input__control > .v-input__slot').type('11999200100')
    
    //inserindo o email
    const email = faker.internet.email()
    cy.get(':nth-child(1) > :nth-child(5) > .v-input > .v-input__control > .v-input__slot').type(email)

    //inserindo data de nascimento
    cy.get(':nth-child(1) > :nth-child(6) > .v-input > .v-input__control > .v-input__slot').type('26072000')

    //inserindo CEP
    cy.get(':nth-child(7) > :nth-child(1) > .v-input > .v-input__control > .v-input__slot').type('08664310')

    //inserindo numero da residencia
    cy.get(':nth-child(7) > :nth-child(6) > .v-input > .v-input__control > .v-input__slot').type('50')

    //inserindo complemento
    cy.get(':nth-child(7) > .v-input > .v-input__control > .v-input__slot').type('Apto 250')

    //inserindo ponto de referencia
    cy.get(':nth-child(8) > .v-input > .v-input__control > .v-input__slot').type('Escola Aprender')
    
    //inserindo senha
    cy.get(':nth-child(1) > .col > .v-input > .v-input__control > .v-input__slot').type('TesteMerca1234')

    //confirmando senha
    cy.get(':nth-child(2) > .col > .v-input > .v-input__control > .v-input__slot').type('TesteMerca1234')

    //aceitando termos
    cy.get('.checkbox-area').click()
    cy.get('#termos-adesao-card').scrollTo('bottom')
    cy.get('#termos-adesao-card > .v-btn--contained').click()

    //confirmando cadastro
    cy.get('.action-buttons').click()
})

it('Inserir CNPJ', () => {
    const meuCnpj = faker.br.cnpj();
    
    cy.get('.v-input__slot').type(meuCnpj)
    cy.get('.v-input__append-outer > .v-btn').click()
})

it('Finalizar cadastro PJ', () => {
    //preenchendo inscricao estadual 
    cy.get(':nth-child(1) > :nth-child(2) > .v-input > .v-input__control > .v-input__slot').type('643633126446')
    
    //preenchendo razao social
    cy.get(':nth-child(1) > :nth-child(3) > .v-input > .v-input__control > .v-input__slot').type('Mercafacil')
    
    //inserindo celular
    cy.get(':nth-child(1) > :nth-child(4) > .v-input > .v-input__control > .v-input__slot').type('11999200123')

    //inserindo telefone contato
    cy.get(':nth-child(1) > :nth-child(5) > .v-input > .v-input__control > .v-input__slot').type('1132200123')

    //inserindo email
    const email = faker.internet.email()
    cy.get(':nth-child(1) > :nth-child(6) > .v-input > .v-input__control > .v-input__slot').type(email)

    //inserindo CEP
    cy.get(':nth-child(7) > :nth-child(1) > .v-input > .v-input__control > .v-input__slot').type('80730-480')

    //inserindo numero da residencia
    cy.get(':nth-child(7) > :nth-child(6) > .v-input > .v-input__control > .v-input__slot').type('1250')

    //inserindo complemento
    cy.get(':nth-child(7) > .v-input > .v-input__control > .v-input__slot').type('Escritorio 360')

    //inserindo ponto de referencia
    cy.get(':nth-child(8) > .v-input > .v-input__control > .v-input__slot').type('Escritorio Mercafacil')
    
    //inserindo senha
    cy.get(':nth-child(1) > .col > .v-input > .v-input__control > .v-input__slot').type('TestecnpjMerca1234')

    //confirmando senha
    cy.get(':nth-child(2) > .col > .v-input > .v-input__control > .v-input__slot').type('TestecnpjMerca1234')

    //aceitando termos
    cy.get('.checkbox-area').click()
    cy.get('#termos-adesao-card').scrollTo('bottom')
    cy.get('#termos-adesao-card > .v-btn--contained').click()

    //confirmando cadastro
    cy.get('.action-buttons').click()
})

